var config = {
    license:"FakeLicense",
    discordname:"Discord#1234"
}